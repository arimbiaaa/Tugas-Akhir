package com.example.tugasakhir;

public class Status {
    public String statusKotak;

    public Status() {
    }

    public String getStatusKotak() {
        return statusKotak;
    }

    public void setStatusKotak(String statusKotak) {
        this.statusKotak = statusKotak;
    }
}


