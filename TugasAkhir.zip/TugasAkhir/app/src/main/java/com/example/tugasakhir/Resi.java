package com.example.tugasakhir;

public class Resi {

    String tanggal,waktu,resi;

    public Resi(){

    }

    public Resi(String resi, String tanggal, String waktu){
        this.resi=resi;
        this.tanggal=tanggal;
        this.waktu=waktu;
    }

    public String getResi() {
        return resi;
    }

    public void setResi(String resi) {
        this.resi = resi;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

}