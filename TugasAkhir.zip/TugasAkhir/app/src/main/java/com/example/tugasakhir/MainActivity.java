package com.example.tugasakhir;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {

    DatabaseReference database,databases;
    String channelid = "APLIKASI KOTAK";
    String channelnotif = "YOHO!" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);

        TextView myTextView =(TextView) findViewById(R.id.textView);
        database = FirebaseDatabase.getInstance().getReference("Alat/Status/");
        databases = FirebaseDatabase.getInstance().getReference("SatusValid");

        databases.addValueEventListener(new ValueEventListener(){

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshots) {
                String status = dataSnapshots.getValue(String.class);
                if (status=="1"){
                    notifs();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        database.addValueEventListener(new ValueEventListener(){

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String myChildText = dataSnapshot.getValue(String.class);
                if (myChildText.equals("PENUH")){
                    myTextView.setText(myChildText);
                    myTextView.setTextColor(Color.parseColor("#FF0000"));
                    notif();
                }else if (myChildText.equals("ADA")){
                    myTextView.setText(myChildText);
                    myTextView.setTextColor(Color.parseColor("#4B84F1"));
                }else if (myChildText.equals("KOSONG")){
                    myTextView.setText(myChildText);
                    myTextView.setTextColor(Color.parseColor("#00FF00"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                myTextView.setText("Error!");
            }
        });


    }

    public void NomorResi(View view) {
        Intent intent = new Intent(MainActivity.this, NomorResi.class);
        startActivity(intent);
    }

    public void Riwayat(View view) {
        Intent intent = new Intent(MainActivity.this,LihatRiwayat.class);
        startActivity(intent);
    }

    private void notif() {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(MainActivity. this, channelid )
                .setSmallIcon(R.mipmap.ic_notif)
                .setAutoCancel(false)
                .setContentTitle( "KOTAK PENUH" )
                .setContentText( "AMBIL PAKETMU" );
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context. NOTIFICATION_SERVICE ) ;
        if (android.os.Build.VERSION. SDK_INT >= android.os.Build.VERSION_CODES. O ) {
            int importance = NotificationManager. IMPORTANCE_MAX ;
            @SuppressLint("WrongConstant") NotificationChannel notificationChannel = new
                    NotificationChannel( channelnotif , "NOTIFIKASI" , importance) ;
            notificationChannel.enableLights( true ) ;
            notificationChannel.setLightColor(Color. RED ) ;
            mBuilder.setChannelId( channelnotif ) ;
            assert mNotificationManager != null;
            mNotificationManager.createNotificationChannel(notificationChannel) ;
        }
        assert mNotificationManager != null;
        mNotificationManager.notify(( int ) System. currentTimeMillis (), mBuilder.build()) ;
    }

    private void notifs() {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(MainActivity. this, channelid )
                .setSmallIcon(R.mipmap.ic_notif)
                .setAutoCancel(false)
                .setContentTitle( "ADA PAKET!" )
                .setContentText( "Paket Baru Dimasukkan" );
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context. NOTIFICATION_SERVICE ) ;
        if (android.os.Build.VERSION. SDK_INT >= android.os.Build.VERSION_CODES. O ) {
            int importance = NotificationManager. IMPORTANCE_MAX ;
            @SuppressLint("WrongConstant") NotificationChannel notificationChannel = new
                    NotificationChannel( channelnotif , "NOTIFIKASI" , importance) ;
            notificationChannel.enableLights( true ) ;
            notificationChannel.setLightColor(Color. RED ) ;
            mBuilder.setChannelId( channelnotif ) ;
            assert mNotificationManager != null;
            mNotificationManager.createNotificationChannel(notificationChannel) ;
        }
        assert mNotificationManager != null;
        mNotificationManager.notify(( int ) System. currentTimeMillis (), mBuilder.build()) ;
    }

}
