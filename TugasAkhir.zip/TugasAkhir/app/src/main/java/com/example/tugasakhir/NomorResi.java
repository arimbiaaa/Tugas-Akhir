package com.example.tugasakhir;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tugasakhir.databinding.NomorresiBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NomorResi extends AppCompatActivity {

    @NonNull NomorresiBinding binding;
    String resi, tanggal, waktu;
    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = NomorresiBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.save.setOnClickListener(v -> {

            SimpleDateFormat date,time;
            date = new SimpleDateFormat("dd-MM-yyyy");
            time = new SimpleDateFormat("HH:mm 'WIB'");
            String nowdate = date.format(new Date());
            String nowtime = time.format(new Date());

            resi = binding.input.getText().toString();
            tanggal = nowdate;
            waktu = nowtime;

            if (!resi.isEmpty() && !tanggal.isEmpty() && !waktu.isEmpty()) {
                Resi dataresi  = new Resi(resi,tanggal,waktu);
                db = FirebaseDatabase.getInstance();
                reference = db.getReference("NomorResi/ResiApp/");
                reference.child(resi).setValue(dataresi).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        binding.input.setText("");
                        Toast.makeText(NomorResi.this, "Sukses di tambahkan!",Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
    }
}